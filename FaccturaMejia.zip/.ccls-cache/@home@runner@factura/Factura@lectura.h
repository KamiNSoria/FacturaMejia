int leerEntero(char*);
int leerEnteroEntre(char*, int, int);
int leerEnteroPositivo(char*);
float leerFlotante(char*);
float leerFlotanteEntre(char*, float, float);
float leerFlotantePositivo(char*);
char leerCaracter(char*);
float leerFlotanteMayorIgual (char* ,float );